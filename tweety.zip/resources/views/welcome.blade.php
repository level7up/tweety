@extends('layouts.app')

@section('content')
    <div class="container">
        <br>
        <h1>10° Task</h1>
    </div>
@endsection