<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta id="token" name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    
    <style type="text/css">
        li{
            padding:20px; 
        }
        a:link{
            text-decoration:none;
            display: inline-block;

        }
        li:hover{
            text-decoration:none;
            background-color: #e7ebef
        }
        body{
            background-color: #e7ebef;
            
        }
        .no-bottom {
            bottom: 0;
            margin-bottom: 0;
        }
    </style>
</head>
<body>
    <div id="app">
        <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="jumbotron no-bottom"></div>
        

       <nav class="navbar navbar-default">
          <div class="container">
            <img src="/uploads/images/<?php echo e($user->image); ?>" style="width:150px;height:150px;border-radius:50%;margin-right:55px;">
            
            <div class="navbar-header col-md-2">
                
                <a href="<?php echo e(url('/' . $user->id)); ?>">
                    <h4><strong><?php echo e($user->name); ?></strong></h4>
                </a>
                <a href="<?php echo e(url('/' . $user->id)); ?>">
                    <small>&#64;<?php echo e($user->name); ?></small>
                </a>
            </div>
            

            <div class="col-md-5">
                <ul class="nav">
                    <li class="<?php echo e(!Route::currentRouteNamed('profile') ?: 'active'); ?>">
                        <a href="<?php echo e(url('/' . $user->id)); ?>" class="text-center">
                            <div class="text-uppercase">Tweets</div>
                        <div><?php echo e($tweets->count()); ?></div>
                        </a>
                    </li>
                    <?php if($is_edit_profile): ?>
                        <li class= "<?php echo e(!Route::currentRouteNamed('following') ?: 'active'); ?>">
                            <a href="<?php echo e(url('/' . $user->id . '/following')); ?>" class="text-center">
                                <div class="text-uppercase">Following</div>
                                <div><?php echo e($following_count); ?></div>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="<?php echo e(!Route::currentRouteNamed('followers') ?: 'active'); ?>">
                        <a href="<?php echo e(url('/' . $user->id . '/followers')); ?>" class="text-center">
                            <div class="text-uppercase">Followers</div>
                            <div><?php echo e($followers_count); ?></div>
                        </a>
                    </li>
                </ul>
            </div>

            <div class="col-md-2">
                    <?php if(Auth::check()): ?>
                    <?php if($is_edit_profile): ?>
                    <a href="#" class="navbar-btn navbar-right">
                        <button type="button" class="btn btn-default">Edit Profile</button>
                    </a>
                    <?php elseif($is_following): ?>
                    <a href="<?php echo e(url('/follows/' . $user->id)); ?>" class="navbar-btn navbar-right">
                        <button type="button" class="btn btn-default">Follow</button>
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e(url('/unfollows/' . $user->id)); ?>" class="navbar-btn navbar-right">
                        <button type="button" class="btn btn-default">Unfollow</button>
                    </a>
                    <?php endif; ?>
                <?php endif; ?>
                </div>
          </div>
        </nav>
        <div class="container">
        <form action="/profile" enctype="multipart/form-data" method="POST">
            <label>Update Profile Image</label>
            <input type="file"  name="image">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <input type="submit" style="float:right" class="btn btn-sm btn-primary">
        </form>

        <br>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->
    
<?php /**PATH F:\Projects\tweety\resources\views/layouts/profile.blade.php ENDPATH**/ ?>