<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 col-md-offset-1">
                <div class="form-group" >
                        <?php echo Form::open(['action'=>'TweetsController@store' , 'method' => 'POST']); ?>

                        
                            <?php echo e(Form::textarea('body','',['class'=> 'form-control','rows'=>'3', 'cols'=>'5', 'maxlength'=>'139','placeholder'=>'What is in your mind'])); ?>      
                            <?php echo e(Form::submit('Submit' ,['class'=> 'btn btn-primary', 'style'=>'float:right;margin-top:-20px'])); ?>

                        <?php echo Form::close(); ?>

                    </div>
                    <br>
            <div class="card">
                
                <div style="text-align:center" class="card-header"><h3>Tweets</h3></div>

                <div class="card-body">
                    <div class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $user->tweets()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="democontainer">
                                <img class="demoimage" src="uploads/images/<?php echo e($tweet->user->image); ?>" style="width:52px;border-radius:50%">
                                <h5 class="demotext"><strong><?php echo e($tweet->user->name); ?></strong></h5>
                            </div>
                            
                            <br>
                            <h4 style="color:#3E7DBA;"><a href="/tweets/<?php echo e($tweet->id); ?>"><?php echo e($tweet->body); ?></a></h4>
                            <small><?php echo e($tweet->created_at); ?></small>
    
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No tweet</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\tweety\resources\views/profile.blade.php ENDPATH**/ ?>