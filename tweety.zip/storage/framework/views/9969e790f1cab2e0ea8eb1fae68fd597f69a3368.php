<?php $__env->startSection('content'); ?>
    <div class="container">
        <br>
        <div class="row justify-content-center">
            <h1>All Tweets even if you don't follow any users.. </h1>
            <div class="col-md-8">
                <?php echo Form::open(['action'=>'TweetsController@store' , 'method' => 'POST']); ?>

                    <div class="form-group">
                        <?php echo e(Form::textarea('body','',['class'=> 'form-control','rows'=>'3', 'cols'=>'5', 'maxlength'=>'139','placeholder'=>'What is in your mind'])); ?>      
                        <?php echo e(Form::submit('Submit' ,['class'=> 'btn btn-primary', 'style'=>'float:right;margin-top:-20px'])); ?>

                    </div>
                <?php echo Form::close(); ?> 
                <br>
                <?php if(count($tweets)>0): ?>
                    <?php $__currentLoopData = $tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="democontainer">
                            <img class="demoimage" src="uploads/images/<?php echo e($tweet->user->image); ?>" style="width:52px;border-radius:50%;object-fit: cover;">
                            <h4 class="demotext"><a style="color:black;text-decoration:none;" href="/<?php echo e($tweet->user_id); ?>"><?php echo e($tweet->user->name); ?></a></h4>
                        </div>
                        <br>
                        <br>
                        <br>
                        <a style="text-decoration:none;" href="/tweets/<?php echo e($tweet->id); ?>">
                            <div >
                                <h4 style="color:#3E7DBA;"><?php echo e($tweet->body); ?></h4>
                                <small><?php echo e($tweet->created_at); ?></small>
                            </div>
                        </a>

                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>NO TWEETS</p>    
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Projects\tweety\resources\views/tweets/index.blade.php ENDPATH**/ ?>